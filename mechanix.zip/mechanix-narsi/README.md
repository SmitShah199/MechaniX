# TK-107446 E-commerce on MERN

***
## Used Technologies
***
- ### Backend  :  Express, NodeJs
- ### Frontend  :  Reactjs
- ### Database : MongoDB
